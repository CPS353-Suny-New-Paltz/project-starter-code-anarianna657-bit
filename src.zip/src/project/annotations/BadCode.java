package project.annotations;

public class BadCode {
	public static void main(String[] args) {
	System.out.println("Hello World");
	}
}
